# Chrome DevTools MCP 分享 Demo 实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**目标：** 构建一个不依赖外部服务的本地“订单工作台”故障演示页，以及一套可直接用于 15-20 分钟内部分享的讲解与兜底材料。

**架构：** 使用 Node.js 内置 `http` 模块提供静态页面和一个真实的本地 API 路由。浏览器页面使用原生 ES Module 管理订单状态和三个确定性故障；服务端 `GET /api/orders?page=2` 稳定返回 HTTP 500，使 Chrome DevTools MCP 可以在 Network 中读取到真实请求证据。分享材料用 Markdown 保存，现场由 Claude Code 调用 Chrome DevTools MCP 完成证据收集。

**技术栈：** Node.js 22、Node 内置 `node:test`、原生 HTML/CSS/JavaScript、Chrome、Claude Code、Chrome DevTools MCP。

---

## 当前状态与文件结构

当前工作区只有设计文档，且不是 Git 仓库。实施时不要擅自执行 `git init`；如果之后将工作区纳入 Git，按每个任务末尾的建议创建检查点提交。

计划产出以下文件：

- `package.json`：定义启动和测试命令。
- `server.mjs`：本地静态服务与确定性的 `500` API 路由。
- `public/index.html`：订单工作台的语义化页面结构。
- `public/styles.css`：紧凑的内部工具页面样式。
- `public/demo-state.mjs`：固定订单数据、筛选逻辑和两个前端故障的最小可测实现。
- `public/app.js`：DOM 渲染、加载/错误/空状态和用户交互，将页面行为连接到预埋故障。
- `test/server.test.mjs`：验证本地服务、静态页面和真实 `500` API 响应。
- `test/demo-state.test.mjs`：验证 Console 异常和 UI 状态不一致可以稳定复现。
- `docs/share/chrome-devtools-mcp-slides.md`：不超过六页的讲解提纲与每页讲稿。
- `docs/share/chrome-devtools-mcp-runbook.md`：分享前检查、三段提示词、时间盒和切换点。
- `docs/share/chrome-devtools-mcp-fallback.md`：每个场景的预期证据和截图占位说明。
- `docs/share/assets/`：现场彩排后保存三张备用截图的位置。

## 任务 1：建立可测试的本地服务和真实 API 失败路由

**文件：**

- 新建：`package.json`
- 新建：`server.mjs`
- 新建：`test/server.test.mjs`

- [ ] **步骤 1：写出服务行为的失败测试**

在 `test/server.test.mjs` 中测试从 `createDemoServer()` 启动的临时服务。测试必须断言 `/api/orders?page=2` 返回 `500`、`application/json`，并包含稳定错误体；同时断言未知 API 路由返回 `404`。

```js
import assert from 'node:assert/strict';
import test from 'node:test';
import { createDemoServer } from '../server.mjs';

async function withServer(run) {
  const server = createDemoServer();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  try {
    await run(`http://127.0.0.1:${port}`);
  } finally {
    await new Promise((resolve, reject) =>
      server.close((error) => (error ? reject(error) : resolve())),
    );
  }
}

test('GET /api/orders?page=2 返回可检查的 500 错误响应', async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/orders?page=2`);
    assert.equal(response.status, 500);
    assert.match(response.headers.get('content-type') ?? '', /application\/json/);
    assert.deepEqual(await response.json(), {
      code: 'ORDER_PAGE_UNAVAILABLE',
      message: 'Unable to load additional orders for demo.',
    });
  });
});

test('未知 API 路由返回 404', async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/unknown`);
    assert.equal(response.status, 404);
  });
});
```

- [ ] **步骤 2：运行测试并确认它失败**

运行：`node --test test/server.test.mjs`

预期：失败，原因是 `../server.mjs` 不存在。

- [ ] **步骤 3：实现最小本地服务**

创建 `package.json`：

```json
{
  "name": "chrome-devtools-mcp-sharing-demo",
  "private": true,
  "type": "module",
  "engines": {
    "node": ">=22"
  },
  "scripts": {
    "start": "node server.mjs",
    "test": "node --test"
  }
}
```

在 `server.mjs` 中导出 `createDemoServer()`。它必须对 `GET /api/orders?page=2` 返回上述 JSON 和 HTTP 500；所有其他 `/api/` 路径返回 404；非 API 路径从 `public/` 提供静态文件。静态路径仅允许位于 `public/` 中，防止 `..` 路径穿越。

```js
import { createReadStream, existsSync } from 'node:fs';
import { stat } from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const rootDir = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(rootDir, 'public');

export function createDemoServer() {
  return http.createServer(async (request, response) => {
    const url = new URL(request.url, 'http://127.0.0.1');
    if (request.method === 'GET' && url.pathname === '/api/orders' && url.searchParams.get('page') === '2') {
      response.writeHead(500, { 'content-type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({
        code: 'ORDER_PAGE_UNAVAILABLE',
        message: 'Unable to load additional orders for demo.',
      }));
      return;
    }
    if (url.pathname.startsWith('/api/')) {
      response.writeHead(404);
      response.end();
      return;
    }
    // 后续步骤补充静态文件响应逻辑。
    response.writeHead(404);
    response.end();
  });
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const server = createDemoServer();
  server.listen(4173, '127.0.0.1', () => {
    console.log('Order Workbench: http://127.0.0.1:4173');
  });
}
```

删除未使用的导入，或在下一任务实现静态文件响应时使用它们；不要保留无用代码。

- [ ] **步骤 4：运行测试并确认通过**

运行：`npm test -- test/server.test.mjs`

预期：两个测试均通过。

- [ ] **步骤 5：版本控制检查点（仅在工作区已纳入 Git 时）**

运行：`git add package.json server.mjs test/server.test.mjs && git commit -m "feat: add local demo server"`

预期：创建一个只包含本任务文件的提交。当前工作区不是 Git 仓库时跳过此步骤，并在实施记录中说明原因。

## 任务 2：实现订单工作台的语义化页面和静态文件服务

**文件：**

- 修改：`server.mjs`
- 新建：`public/index.html`
- 新建：`public/styles.css`
- 新建：`public/app.js`
- 修改：`test/server.test.mjs`

- [ ] **步骤 1：为页面骨架和静态资源写失败测试**

向 `test/server.test.mjs` 增加测试，要求首页返回 HTML，且包含演示必需的稳定选择器；同时要求 CSS 返回 `text/css`，`/app.js` 返回 JavaScript。`app.js` 在本任务只作为零副作用占位模块存在，避免页面从任务 2 起产生脚本 404；任务 3 再填入交互逻辑。

```js
test('首页提供订单工作台和全部演示控件', async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/`);
    const html = await response.text();
    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type') ?? '', /text\/html/);
    for (const marker of [
      'data-testid="refresh-orders"',
      'data-testid="load-more"',
      'data-testid="pending-only"',
      'data-testid="reset-demo"',
      'data-testid="pending-count"',
      'data-testid="order-list"',
    ]) {
      assert.ok(html.includes(marker), `缺少 ${marker}`);
    }
  });
});

test('样式文件作为 CSS 返回', async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/styles.css`);
    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type') ?? '', /text\/css/);
  });
});

test('应用脚本占位模块作为 JavaScript 返回', async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/app.js`);
    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type') ?? '', /javascript/);
  });
});
```

- [ ] **步骤 2：运行新增测试并确认失败**

运行：`npm test -- test/server.test.mjs`

预期：首页、CSS 和应用脚本测试失败，因为静态资源尚未存在或服务器尚未提供静态文件。

- [ ] **步骤 3：实现静态文件服务与页面结构**

补全 `server.mjs` 的非 API 分支：将 `/` 映射到 `public/index.html`，其余路径映射到 `public/` 下的文件；使用 `path.resolve` 验证结果仍以 `publicDir` 开头；为 `.html`、`.css`、`.js` 和 `.mjs` 返回正确的 Content-Type。

在 `public/index.html` 中创建下列核心结构，不加入外部字体、图片或 CDN：

```html
<main class="workbench">
  <header class="topbar">
    <div>
      <p class="eyebrow">Support Operations</p>
      <h1>订单工作台</h1>
    </div>
    <button type="button" data-testid="reset-demo">重置演示</button>
  </header>

  <section class="summary" aria-label="订单汇总">
    <p>订单总数 <strong data-testid="total-count"></strong></p>
    <p>待处理订单 <strong data-testid="pending-count"></strong></p>
  </section>

  <section class="toolbar" aria-label="订单操作">
    <button type="button" data-testid="refresh-orders">刷新订单</button>
    <button type="button" data-testid="load-more">加载更多</button>
    <label><input type="checkbox" data-testid="pending-only"> 仅看待处理</label>
  </section>

  <p class="feedback" role="status" data-testid="feedback"></p>
  <ul class="order-list" data-testid="order-list" aria-label="订单列表"></ul>
</main>
<script type="module" src="/app.js"></script>
```

在 `public/styles.css` 中使用紧凑、低圆角（不超过 `8px`）的内部工具样式。必须保证按钮、筛选控件、汇总区域、反馈文本和订单行在桌面与窄屏下不重叠；使用 CSS Grid 或 Flexbox，而不是绝对定位布局。

创建 `public/app.js`，只保留一个简短注释或空模块，不绑定事件、不写 DOM、不发请求。此文件的唯一作用是让任务 2 的页面脚本引用可解析；任务 3 负责实现真实页面交互。

- [ ] **步骤 4：运行服务测试并人工检查布局**

运行：`npm test -- test/server.test.mjs`

预期：所有服务测试通过。

运行：`npm run start`

预期：终端输出 `Order Workbench: http://127.0.0.1:4173`。在专用终端中保持该进程运行，在 Chrome 打开该地址，确认页面标题、四个控件和空列表骨架可见，且没有布局重叠。后续任务复用这一个进程；不需要时使用 `Ctrl-C` 停止它，避免再次启动时占用固定端口 `4173`。

- [ ] **步骤 5：版本控制检查点（仅在工作区已纳入 Git 时）**

运行：`git add server.mjs public/index.html public/styles.css public/app.js test/server.test.mjs && git commit -m "feat: add order workbench shell"`

预期：创建只包含页面外壳和静态服务的提交；非 Git 工作区跳过。

## 任务 3：实现可稳定复现的 Console 和 UI 状态问题

**文件：**

- 新建：`public/demo-state.mjs`
- 修改：`public/app.js`
- 新建：`test/demo-state.test.mjs`

- [ ] **步骤 1：为两个前端问题写失败测试**

创建 `test/demo-state.test.mjs`。测试的目标不是修复问题，而是锁定演示用的故障行为，使其不会在后续修改中消失。

```js
import assert from 'node:assert/strict';
import test from 'node:test';
import {
  INITIAL_ORDERS,
  getDisplayedPendingCount,
  getVisibleOrders,
  triggerRefreshFailure,
} from '../public/demo-state.mjs';

test('开启待处理筛选后，待处理数量与可见订单行稳定不一致', () => {
  const visibleOrders = getVisibleOrders(INITIAL_ORDERS, true);
  const displayedCount = getDisplayedPendingCount(INITIAL_ORDERS, true);
  assert.ok(visibleOrders.length < INITIAL_ORDERS.length);
  assert.equal(displayedCount, INITIAL_ORDERS.length);
  assert.notEqual(displayedCount, visibleOrders.length);
});

test('刷新订单稳定抛出 TypeError 供 Console 定位', () => {
  assert.throws(triggerRefreshFailure, TypeError);
});
```

- [ ] **步骤 2：运行测试并确认失败**

运行：`node --test test/demo-state.test.mjs`

预期：失败，原因是 `public/demo-state.mjs` 不存在。

- [ ] **步骤 3：实现固定数据、故障函数和页面交互**

在 `public/demo-state.mjs` 中导出固定订单数组、`getVisibleOrders`、`getDisplayedPendingCount` 和 `triggerRefreshFailure`。订单数据至少包含六条记录，并且待处理订单数少于总订单数。

```js
export const INITIAL_ORDERS = Object.freeze([
  { id: 'ORD-1048', customer: 'Northwind', status: 'pending', amount: 1840 },
  { id: 'ORD-1047', customer: 'Contoso', status: 'complete', amount: 960 },
  { id: 'ORD-1046', customer: 'Fabrikam', status: 'pending', amount: 720 },
  { id: 'ORD-1045', customer: 'Adventure Works', status: 'complete', amount: 1510 },
  { id: 'ORD-1044', customer: 'Tailspin Toys', status: 'pending', amount: 440 },
  { id: 'ORD-1043', customer: 'Wide World Importers', status: 'complete', amount: 2080 },
]);

export function getVisibleOrders(orders, pendingOnly) {
  return pendingOnly ? orders.filter((order) => order.status === 'pending') : orders;
}

export function getDisplayedPendingCount(orders, pendingOnly) {
  return pendingOnly
    ? orders.length
    : orders.filter((order) => order.status === 'pending').length;
}

export function triggerRefreshFailure() {
  const refreshPayload = {};
  return refreshPayload.customer.name;
}
```

`getDisplayedPendingCount` 中看似错误的筛选分支是刻意保留的演示故障：开启“仅看待处理”后，它错误返回未筛选的总数。不要在实施中“顺手修复”。

在 `public/app.js` 中：

- 从 `demo-state.mjs` 导入上述导出项。
- 渲染 `total-count`、`pending-count` 和订单行；订单行必须包含订单号、客户名、状态和金额。开启“仅看待处理”后，`pending-count` 故意显示 6，而订单行只显示 3 条，供场景 C 对比。
- 筛选复选框改变时，重新渲染列表与汇总。
- 点击“刷新订单”时先把反馈文本设为“刷新未完成，订单仍为旧数据。”，再调用 `triggerRefreshFailure()`，让未捕获的 `TypeError` 写入浏览器 Console。
- 点击“加载更多”时先把反馈文本设为“正在加载更多订单...”，再执行 `fetch('/api/orders?page=2')`；响应非成功时读取 JSON，将反馈文本设为“加载更多失败：Unable to load additional orders for demo.”，但不要吞掉请求证据或伪造成功结果。
- 用 `feedbackState` 区分 `idle`、`loading`、`error` 和 `empty`。当 `orders.length === 0` 时渲染“没有可显示的订单”空状态；支持仅用于验证的 `?scenario=empty` 查询参数，让初始订单数组为空。该参数不写入分享主流程。
- 点击“重置演示”时恢复未筛选状态、原始订单、空反馈文本，并重新渲染。
- 页面以原生 ES Module 直接加载 `app.js` 和 `demo-state.mjs`，不得压缩、合并或转译；这样 Console 堆栈直接显示原始文件 URL 与行号。若实施中加入构建工具，必须生成并由静态服务提供对应 source map。

- [ ] **步骤 4：运行单元测试并验证三个页面行为**

运行：`npm test`

预期：`server.test.mjs` 和 `demo-state.test.mjs` 中的所有测试通过。

先运行 `curl -I http://127.0.0.1:4173`。若服务未运行，在专用终端执行 `npm run start`；若已运行则复用，禁止启动第二个实例。随后在 Chrome 中逐项检查：

1. 点击“刷新订单”后，反馈文本出现，Console 出现 `TypeError`。
2. 点击“加载更多”后，页面显示加载失败；Network 中出现 `GET /api/orders?page=2` 的 HTTP 500 响应和 JSON 错误体。
3. 开启“仅看待处理”后，“待处理订单”错误显示 6，而订单行只显示 3 条。
4. 打开 `http://127.0.0.1:4173/?scenario=empty`，确认显示“没有可显示的订单”空状态。
5. 点击“重置演示”后，所有状态恢复到初始值。

- [ ] **步骤 5：版本控制检查点（仅在工作区已纳入 Git 时）**

运行：`git add public/demo-state.mjs public/app.js test/demo-state.test.mjs && git commit -m "feat: add reproducible debugging scenarios"`

预期：创建只包含故障逻辑与其锁定测试的提交；非 Git 工作区跳过。

## 任务 4：编写分享幻灯片提纲、现场脚本和备用结论

**文件：**

- 新建：`docs/share/chrome-devtools-mcp-slides.md`
- 新建：`docs/share/chrome-devtools-mcp-runbook.md`
- 新建：`docs/share/chrome-devtools-mcp-fallback.md`
- 新建：`docs/share/assets/.gitkeep`

- [ ] **步骤 1：先列出材料验收清单**

在每个 Markdown 文档顶部写明其目标读者与使用时机。先列出以下验收点，后续内容必须逐项满足：

- 幻灯片不超过六页，且不比较模型。
- 讲解脚本包含 Claude Code、Chrome DevTools MCP、固定本地 URL 和三条“不要修改代码”的提示词。
- 每段演示包含两分钟时限和切换到备用截图的条件。
- 备用结论明确“症状 -> 证据 -> 可能原因 -> 下一步”。
- 安全说明覆盖敏感数据与有副作用的浏览器操作。

- [ ] **步骤 2：确认材料尚未齐备**

运行：`rg -n "刷新订单后列表没有更新|加载更多|仅看待处理|不要修改代码" docs/share`

预期：失败或输出不完整，因为分享材料尚未创建。

- [ ] **步骤 3：创建三份分享材料**

`docs/share/chrome-devtools-mcp-slides.md` 必须恰好包含六个一级内容页：

1. 一句话结果：用 Agent 收集浏览器调试证据。
2. 调用链：Claude Code -> Chrome DevTools MCP -> 浏览器信号。
3. 能力地图：UI、Console、Network、截图、性能。
4. 订单工作台与三个预埋问题。
5. 三段演示的“症状 -> 证据 -> 可能原因”。
6. 日常提示词、边界和下一步。

`docs/share/chrome-devtools-mcp-runbook.md` 必须按分钟写明：分享前检查、本地 URL `http://127.0.0.1:4173`、目标 Chrome 页面选择、三段提示词、每段的两分钟时限和降级规则。三条提示词使用设计文档中的版本，并均以“不要修改代码”结束。Network 场景的预期证据必须包含请求 URL、HTTP 500、JSON 响应体和请求时间或耗时。

`docs/share/chrome-devtools-mcp-fallback.md` 为三个场景分别记录以下结构：

```markdown
### 场景：Console 刷新异常

- 症状：刷新后订单列表未变化。
- 证据：`TypeError`、堆栈、列表快照。
- 可能原因：刷新处理函数访问了缺失的嵌套属性。
- 下一步：修正数据契约或在访问前做空值校验，并补充单元测试。
- 备用截图：`docs/share/assets/console-refresh-error.png`
```

Network 场景的“证据”项必须明确记录请求 URL、HTTP 500、JSON 响应体和请求时间或耗时。另一个 UI 场景使用对应的 `network-500.png` 和 `ui-state-mismatch.png` 文件名。创建空目录占位文件 `docs/share/assets/.gitkeep`；图片将在任务 5 的现场彩排中生成。

- [ ] **步骤 4：验证分享材料覆盖完整**

运行：`rg -n "不要修改代码|两分钟|500|副作用|生产数据" docs/share/chrome-devtools-mcp-*.md`

预期：每个关键主题至少出现一次，且三条提示词均可直接复制。

- [ ] **步骤 5：版本控制检查点（仅在工作区已纳入 Git 时）**

运行：`git add docs/share && git commit -m "docs: add Chrome DevTools MCP sharing materials"`

预期：创建只包含分享材料的提交；非 Git 工作区跳过。

## 任务 5：完成 MCP 彩排、保存备用证据并执行最终验证

**文件：**

- 新建：`docs/share/rehearsal-checklist.md`
- 新建：`docs/share/assets/console-refresh-error.png`
- 新建：`docs/share/assets/network-500.png`
- 新建：`docs/share/assets/ui-state-mismatch.png`
- 修改：`docs/share/chrome-devtools-mcp-fallback.md`

- [ ] **步骤 1：写出彩排验收清单**

创建 `docs/share/rehearsal-checklist.md`，为下列项提供复选框和记录实际完成时间的空位：

```markdown
- [ ] 本地服务在 `http://127.0.0.1:4173` 运行。
- [ ] Claude Code 能列出页面并选中订单工作台。
- [ ] Claude Code 能读取页面快照与 Console。
- [ ] Console 场景在两分钟内得到 `TypeError` 证据。
- [ ] Network 场景在两分钟内得到 HTTP 500、URL、响应体和请求时间或耗时。
- [ ] UI 场景在两分钟内得到汇总值与订单行不一致的证据。
- [ ] 三张备用截图已保存且文件名与 fallback 文档一致。
- [ ] 分享期间不会使用生产登录态、真实用户数据或会产生副作用的操作。
```

- [ ] **步骤 2：确认彩排产物尚不存在**

运行：`test -f docs/share/assets/console-refresh-error.png`

预期：返回非零状态，因为还没有进行彩排截图。

- [ ] **步骤 3：执行一次完整的 MCP 彩排**

运行：`npm test`

预期：测试全部通过。

运行：`curl -I http://127.0.0.1:4173`

预期：返回 HTTP 200。若没有服务在监听，在一个专用终端执行 `npm run start` 后重试；若服务已在运行，直接复用，禁止再启动第二个实例。

在独立 Chrome 测试 Profile 中打开该 URL。通过 Claude Code 依次执行 `chrome-devtools` MCP 的页面选择、快照、点击、Console 和 Network 检查。使用 Chrome DevTools MCP 的 `take_screenshot` 工具并传入明确的 `filePath` 和 `format: "png"`，将截图直接保存为：

- `docs/share/assets/console-refresh-error.png`
- `docs/share/assets/network-500.png`
- `docs/share/assets/ui-state-mismatch.png`

记录 Network 请求的时间或耗时到 `chrome-devtools-mcp-fallback.md`。在 `rehearsal-checklist.md` 中勾选完成项，记录每个场景耗时；若任一场景超过两分钟，在 `chrome-devtools-mcp-runbook.md` 中明确写入实际的切换点。

- [ ] **步骤 4：做最终自动与人工验证**

运行：`npm test`

预期：所有 Node 测试通过。

运行：`rg -n "console-refresh-error.png|network-500.png|ui-state-mismatch.png" docs/share/chrome-devtools-mcp-fallback.md`

预期：三个备用截图路径均存在于 fallback 文档中。

人工确认：三张 PNG 可打开、页面未出现重叠文本、Console 场景确有异常、Network 场景确有 HTTP 500、UI 场景中汇总值与可见订单行可直接比较。

- [ ] **步骤 5：版本控制检查点（仅在工作区已纳入 Git 时）**

运行：`git add docs/share && git commit -m "docs: add rehearsal evidence"`

预期：创建包含彩排记录与备用证据的提交；非 Git 工作区跳过。
