import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import test from 'node:test';
import { createDemoServer } from '../server.mjs';

async function withServer(run, createServer = createDemoServer) {
  const server = createServer();
  await new Promise((resolve, reject) => {
    const onError = (error) => reject(error);
    server.once('error', onError);
    server.listen(0, '127.0.0.1', () => {
      server.removeListener('error', onError);
      resolve();
    });
  });
  const { port } = server.address();

  try {
    await run(`http://127.0.0.1:${port}`);
  } finally {
    await new Promise((resolve, reject) =>
      server.close((error) => (error ? reject(error) : resolve())),
    );
  }
}

test('withServer rejects when its temporary server fails to listen', async () => {
  const listenError = new Error('Unable to listen');
  const server = new EventEmitter();

  server.listen = () => {
    queueMicrotask(() => server.emit('error', listenError));
  };

  // Avoid EventEmitter's unhandled-error throw so the Promise outcome is testable.
  const emit = server.emit.bind(server);
  server.emit = (event, ...args) =>
    event === 'error' && server.listenerCount('error') === 0
      ? false
      : emit(event, ...args);

  const timeoutError = new Error('withServer did not reject for a listen error');
  const outcome = await Promise.race([
    withServer(async () => assert.fail('run must not be called'), () => server).then(
      () => new Error('withServer resolved unexpectedly'),
      (error) => error,
    ),
    new Promise((resolve) => setTimeout(() => resolve(timeoutError), 20)),
  ]);

  assert.equal(outcome, listenError);
});

test('GET /api/orders?page=2 returns an inspectable 500 response', async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/orders?page=2`);

    assert.equal(response.status, 500);
    assert.match(
      response.headers.get('content-type') ?? '',
      /application\/json/,
    );
    assert.deepEqual(await response.json(), {
      code: 'ORDER_PAGE_UNAVAILABLE',
      message: 'Unable to load additional orders for demo.',
    });
  });
});

test('GET /api/unknown returns 404', async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/unknown`);

    assert.equal(response.status, 404);
  });
});

test('GET / serves the order workbench and its stable controls', async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/`);
    const html = await response.text();

    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type') ?? '', /text\/html/);
    for (const marker of [
      'data-testid="refresh-orders"',
      'data-testid="load-more"',
      'data-testid="leak-memory"',
      'data-testid="pending-only"',
      'data-testid="reset-demo"',
      'data-testid="pending-count"',
      'data-testid="order-list"',
    ]) {
      assert.ok(html.includes(marker), `missing ${marker}`);
    }
    assert.ok(html.includes('批量制造内存泄漏'));
  });
});

test('HEAD / confirms the order workbench is available', async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/`, { method: 'HEAD' });

    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type') ?? '', /text\/html/);
  });
});

test('GET /styles.css serves a CSS response', async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/styles.css`);

    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type') ?? '', /text\/css/);
  });
});

test('GET /app.js serves a JavaScript response', async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/app.js`);
    const script = await response.text();

    assert.equal(response.status, 200);
    assert.match(
      response.headers.get('content-type') ?? '',
      /application\/javascript/,
    );
    assert.match(script, /const leakBatchSize = 10_000;/);
  });
});
