import assert from 'node:assert/strict';
import test from 'node:test';
import {
  INITIAL_ORDERS,
  getDisplayedPendingCount,
  getVisibleOrders,
  triggerRefreshFailure,
} from '../public/demo-state.mjs';

test('开启待处理筛选后，待处理数量与可见订单行稳定不一致', () => {
  const visibleOrders = getVisibleOrders(INITIAL_ORDERS, true);
  const displayedCount = getDisplayedPendingCount(INITIAL_ORDERS, true);
  assert.ok(visibleOrders.length < INITIAL_ORDERS.length);
  assert.equal(displayedCount, INITIAL_ORDERS.length);
  assert.notEqual(displayedCount, visibleOrders.length);
});

test('刷新订单稳定抛出 TypeError 供 Console 定位', () => {
  assert.throws(triggerRefreshFailure, TypeError);
});
