import { readFile } from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const additionalOrdersError = {
  code: 'ORDER_PAGE_UNAVAILABLE',
  message: 'Unable to load additional orders for demo.',
};

const rootDir = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.resolve(rootDir, 'public');
const contentTypes = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
};

function sendNotFound(response) {
  response.writeHead(404);
  response.end();
}

export function createDemoServer() {
  return http.createServer(async (request, response) => {
    const url = new URL(request.url, 'http://127.0.0.1');

    if (
      request.method === 'GET' &&
      url.pathname === '/api/orders' &&
      url.search === '?page=2'
    ) {
      response.writeHead(500, {
        'content-type': 'application/json; charset=utf-8',
      });
      response.end(JSON.stringify(additionalOrdersError));
      return;
    }

    if (url.pathname.startsWith('/api/')) {
      sendNotFound(response);
      return;
    }

    if (request.method !== 'GET' && request.method !== 'HEAD') {
      response.writeHead(405, { allow: 'GET, HEAD' });
      response.end();
      return;
    }

    let pathname;
    try {
      pathname = decodeURIComponent(url.pathname);
    } catch {
      sendNotFound(response);
      return;
    }

    const relativePath = pathname === '/' ? 'index.html' : pathname.slice(1);
    const filePath = path.resolve(publicDir, relativePath);
    const publicPrefix = `${publicDir}${path.sep}`;

    if (!filePath.startsWith(publicPrefix)) {
      sendNotFound(response);
      return;
    }

    try {
      const content = await readFile(filePath);
      const contentType =
        contentTypes[path.extname(filePath)] ?? 'application/octet-stream';

      response.writeHead(200, { 'content-type': contentType });
      response.end(request.method === 'HEAD' ? undefined : content);
    } catch {
      sendNotFound(response);
    }
  });
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const server = createDemoServer();
  server.listen(4173, '127.0.0.1', () => {
    console.log('Order Workbench: http://127.0.0.1:4173');
  });
}
