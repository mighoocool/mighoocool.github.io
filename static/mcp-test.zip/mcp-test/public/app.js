import {
  INITIAL_ORDERS,
  getDisplayedPendingCount,
  getVisibleOrders,
  triggerRefreshFailure,
} from './demo-state.mjs';

const totalCount = document.querySelector('[data-testid="total-count"]');
const pendingCount = document.querySelector('[data-testid="pending-count"]');
const orderList = document.querySelector('[data-testid="order-list"]');
const feedback = document.querySelector('[data-testid="feedback"]');
const pendingOnly = document.querySelector('[data-testid="pending-only"]');
const refreshOrders = document.querySelector('[data-testid="refresh-orders"]');
const loadMore = document.querySelector('[data-testid="load-more"]');
const leakMemory = document.querySelector('[data-testid="leak-memory"]');
const resetDemo = document.querySelector('[data-testid="reset-demo"]');

const amountFormatter = new Intl.NumberFormat('zh-CN', {
  style: 'currency',
  currency: 'USD',
  maximumFractionDigits: 0,
});

const url = new URL(window.location.href);
let orders = url.searchParams.get('scenario') === 'empty' ? [] : [...INITIAL_ORDERS];
let feedbackState = 'idle';
const leakBatchSize = 10_000;
const leakedRecords = [];

function setFeedback(state, message = '') {
  feedbackState = state;
  feedback.dataset.state = feedbackState;
  feedback.textContent = message;
}

function createOrderRow(order) {
  const row = document.createElement('li');

  const details = document.createElement('span');
  details.textContent = `${order.id} - ${order.customer}`;

  const meta = document.createElement('span');
  meta.textContent = `${order.status} - ${amountFormatter.format(order.amount)}`;

  row.append(details, meta);
  return row;
}

function renderOrders(visibleOrders) {
  orderList.replaceChildren();

  if (orders.length === 0) {
    const emptyRow = document.createElement('li');
    emptyRow.textContent = '没有可显示的订单';
    orderList.append(emptyRow);
    setFeedback('empty');
    return;
  }

  for (const order of visibleOrders) {
    orderList.append(createOrderRow(order));
  }
}

function render() {
  const onlyPending = pendingOnly.checked;
  const visibleOrders = getVisibleOrders(orders, onlyPending);

  totalCount.textContent = String(orders.length);
  pendingCount.textContent = String(
    getDisplayedPendingCount(orders, onlyPending),
  );
  renderOrders(visibleOrders);
}

pendingOnly.addEventListener('change', () => {
  render();
});

refreshOrders.addEventListener('click', () => {
  setFeedback('error', '刷新未完成，订单仍为旧数据。');
  triggerRefreshFailure();
});

loadMore.addEventListener('click', async () => {
  setFeedback('loading', '正在加载更多订单...');

  try {
    const response = await fetch('/api/orders?page=2');

    if (!response.ok) {
      const error = await response.json();
      setFeedback('error', `加载更多失败：${error.message}`);
      return;
    }

    const moreOrders = await response.json();
    orders = [...orders, ...moreOrders];
    setFeedback('idle');
    render();
  } catch (error) {
    setFeedback('error', `加载更多失败：${error.message}`);
  }
});

leakMemory.addEventListener('click', () => {
  for (let index = 0; index < leakBatchSize; index += 1) {
    const leakId = leakedRecords.length + 1;
    const detachedNode = document.createElement('section');
    detachedNode.textContent = `leaked node ${leakId}`;
    detachedNode.dataset.leak = 'retained-detached-node';

    leakedRecords.push({
      createdAt: new Date().toISOString(),
      detachedNode,
      payload: new Array(5_000).fill(`order-leak-${leakId}`),
    });
  }

  setFeedback('error', `已制造 ${leakedRecords.length} 组保留引用。`);
});

resetDemo.addEventListener('click', () => {
  orders = [...INITIAL_ORDERS];
  pendingOnly.checked = false;
  setFeedback('idle');
  render();
});

render();
