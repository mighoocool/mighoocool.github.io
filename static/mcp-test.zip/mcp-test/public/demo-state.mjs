export const INITIAL_ORDERS = [
  {
    id: 'ORD-1048',
    customer: 'Northwind',
    status: 'pending',
    amount: 1840,
  },
  {
    id: 'ORD-1047',
    customer: 'Contoso',
    status: 'complete',
    amount: 960,
  },
  {
    id: 'ORD-1046',
    customer: 'Fabrikam',
    status: 'pending',
    amount: 720,
  },
  {
    id: 'ORD-1045',
    customer: 'Adventure Works',
    status: 'complete',
    amount: 1510,
  },
  {
    id: 'ORD-1044',
    customer: 'Tailspin Toys',
    status: 'pending',
    amount: 440,
  },
  {
    id: 'ORD-1043',
    customer: 'Wide World Importers',
    status: 'complete',
    amount: 2080,
  },
];

export function getVisibleOrders(orders, pendingOnly) {
  return pendingOnly
    ? orders.filter((order) => order.status === 'pending')
    : orders;
}

export function getDisplayedPendingCount(orders, pendingOnly) {
  if (pendingOnly) {
    return orders.length;
  }

  return orders.filter((order) => order.status === 'pending').length;
}

export function triggerRefreshFailure() {
  const refreshPayload = {};
  return refreshPayload.customer.name;
}
